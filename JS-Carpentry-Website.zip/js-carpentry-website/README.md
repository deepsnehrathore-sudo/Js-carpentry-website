# JS Carpentry Website

A responsive static website ready for GitHub Pages.

## Publish with GitHub Pages

1. Create a new public GitHub repository named `js-carpentry-website`.
2. Upload every file and folder from this package to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**.
5. Choose the `main` branch and `/ (root)`, then press **Save**.
6. GitHub will provide the live website address after deployment.

## Custom domain

In **Settings → Pages**, enter your domain under **Custom domain**. Your domain registrar will then need the DNS records shown by GitHub.

## Quote form

The quote form opens the visitor's email application and prepares an email to `jscarpentrypvtltd@gmail.com`. Visitors can attach plans before sending.

## Edit details

- Main page content: `index.html`
- Design: `styles.css`
- Interactions: `script.js`
- Images: `assets/images/`
